import spacy
import neuralcoref
from openie import StanfordOpenIE

print("****************************************************")
print("***          Part 1 : Using NeuralCoref          ***")
print("****************************************************\n")

def NeuralCoref(text, visualize=False, debug=False):
    nlp = spacy.load('en')
    neuralcoref.add_to_pipe(nlp)

    doc = nlp(text)

    if visualize: print("==> INPUT String: \n%s" % text);
    for i in range(len(doc._.coref_clusters)):
        a = doc._.coref_clusters[i].mentions[-1]
        b = doc._.coref_clusters[i].mentions[-1]._.coref_cluster.main
        text = text.replace(str(a), str(b))
        if debug: print("|- ", text);
    if visualize: print("\n==> OUTPUT String: \n%s" % text);

    return text

""" Begin with a simple 1 sentence string. """
str_1 = 'John have dinner today and he enjoyed it.'
""" Replace NeuralCoref parameter with desired string """
a = NeuralCoref(str_1, visualize=True)



# -------------------------------------------------------
print("\n****************************************************\n")

print("Looking at some differences found between running on Windows Vs. Linux\n")

""" Using a different sentence """
str_2 = 'My sister has a dog. She loves him.'

print("==> INPUT String: \n%s\n" % str_2);

""" Obtain clusters for string 2 (on linux system) """
print("\n==> OUTPUT String [Ubuntu Machine] <==");
linux = NeuralCoref(str_2, debug=True)

print("\n==> OUTPUT String [Windows Machine] <==");
print("|- My sister  has a dog. My sister loves a dog.")


print("\n\n****************************************************")
print("***            Part 2 : Using OpenIE             ***")
print("****************************************************\n")

from openie import StanfordOpenIE
def OpenIE(text, visualize=False, debug=False):
    with StanfordOpenIE() as client:
        i=1
        if visualize: print("==> INPUT String: \n%s" % text);
        if visualize: print("\n==> OUTPUT:");
        for triple in client.annotate(text):
            if i: i=0; print();
            print("==> ", triple)

# Returning back our simple 1 sentence string
str_1 = 'John have dinner today and he enjoyed it.'

# Replace OpenIE parameter with desired string
b = OpenIE(str_1, visualize=True)


print("\n\n****************************************************")
print("***   Part 3 : Using NeuralCoref -> OpenIE       ***")
print("****************************************************\n")


# Replace NeuralCoref parameter with desired string

# Step 1.) Run co-reference resolution on string using NeuralCoref.
print("Step 1.) Apply Co-Reference Resolution using spaCy NeuralCoref\n")
nc = NeuralCoref(str_1, visualize=True)


# Step 2.) Run the output through OpenIE
print("\n\nStep 2.) Apply the information extraction algorithm found within Stanford's OpenIE tools to the outputted string from step 1\n")
c = OpenIE(nc, visualize=True)
