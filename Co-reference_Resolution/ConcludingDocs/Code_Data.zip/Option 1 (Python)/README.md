### Description
The following gist provides instructions on how to run & use the NeuralCoref & OpenIE
python package's within a (python 3.8) Anaconda environment.

We'll use `conda` & `pip` commands via the anaconda terminal to install packages.

1. __Create a new anaconda environment__
```sh
conda create -n NLP python==3.8
conda activate NLP
```

2. Install spacy, neuralcoref, & openie
     - Linux Instructions (pip)
```sh
pip install -U pip setuptools wheel
pip install spacy neuralcoref standford-openie
python -m spacy download en
```

     - Linux Instructions (conda)
```sh
conda install -c conda-forge spacy neuralcoref
python -m spacy download en
```

     - Windows Instructions (or if Linux instructions fail)
```sh
git clone https://github.com/huggingface/neuralcoref.git
cd neuralcoref
pip install -r requirements.txt
pip install -e .
python -m spacy download en
pip install stanford-openie
```

3. __Compile!.__
     - Run <code>$ python Co-reference_Resolution.py</code> in terminal.
     
     
     
     
     
4. __Other Information__
     - To view the output of OpenIE's demo as shown on their [website](https://stanfordnlp.github.io/CoreNLP/openie.html):
     	- Pre-requisites: Java8+, and [Stanford CoreNLP API files](https://github.com/stanfordnlp/CoreNLP/archive/refs/tags/v4.2.1.zip)
     	
    - To run the demo, run the following in your terminal <code>java -cp "stanford-corenlp-4.2.0/*" -Xmx5g edu.stanford.nlp.pipeline.StanfordCoreNLP -file ex.txt; </code>

