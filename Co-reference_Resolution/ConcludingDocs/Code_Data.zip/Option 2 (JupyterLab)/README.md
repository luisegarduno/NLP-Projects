### Description
The following gist provides instructions on how to run & use the NeuralCoref python package within
Jupyter Notebook or Jupyter Lab that is in an Anaconda environment (LINUX ONLY). Also shown 

We'll use `conda` & `pip` commands via the anaconda terminal to install packages.

1. __Create a new anaconda environment__
```sh
conda create -n NLP python==3.8
conda activate NLP
```

2. __(_Optional_) Install NLTK, Gensim, WordNet__
```sh
conda install -c r r-wordnet
conda install -c anaconda nltk gensim
```

3. __Choose 1 of the following options below & within your anaconda terminal, run all the commands for it.__
     - Option 1 : JupyterLab w/ git & github (jsonschema==3.2.0)
     ```sh
     conda install -c conda-forge jupyterlab jupyter_contrib_nbextensions
     conda install -c conda-forge jupyterlab==2.2.6 jupyter_client==6.1.7
     pip install jupyterlab-git==0.23.3 jupyterlab-github==2.0.0 spacy==2.1.3 cython pytest neuralcoref jsonschema==3.2.0
     ```
     - Option 2 : JupyterLab w/ git & github (jsonschema==2.6.0)
     ```sh
     conda install -c conda-forge jupyterlab==2.2.6 jupyter_client==6.1.7 jupyter_contrib_nbextensions
     pip install jupyterlab-git==0.23.3 jupyterlab-github==2.0.0 spacy==2.1.3 cython pytest neuralcoref
     ```
     - Option 3 : Jupyter Notebook
     ```sh
     conda install -c conda-forge notebook nb_conda_kernels jupyter_contrib_nbextensions
     pip install spacy==2.1.3 cython pytest neuralcoref
     ```
4. __Install SpaCy's model__ : `python -m spacy download en`
5. __Create a new jupyter notebook, then copy & run the snippet from [SpaCy's example](https://spacy.io/universe/project/neuralcoref) inside your notebook to verify NeuralCoref works accordingly__.